// Lista de alunos
let alunos = [];

// Inputs e botão
let inputNome, inputIdade, inputCpf, inputSexo, botaoCadastrar;

function setup() {
  createCanvas(600, 400);
  textSize(14);

  // Criar campos de entrada
  inputNome = createInput();
  inputNome.position(20, 20);
  inputNome.attribute("placeholder", "Nome");

  inputIdade = createInput();
  inputIdade.position(20, 50);
  inputIdade.attribute("placeholder", "Idade");

  inputCpf = createInput();
  inputCpf.position(20, 80);
  inputCpf.attribute("placeholder", "CPF");

  inputSexo = createInput();
  inputSexo.position(20, 110);
  inputSexo.attribute("placeholder", "Sexo");

  // Botão para cadastrar
  botaoCadastrar = createButton("Cadastrar Aluno");
  botaoCadastrar.position(20, 140);
  botaoCadastrar.mousePressed(() => {
    cadastrarAluno(
      inputNome.value(),
      inputIdade.value(),
      inputCpf.value(),
      inputSexo.value()
    );

    // Limpar os campos após cadastrar
    inputNome.value("");
    inputIdade.value("");
    inputCpf.value("");
    inputSexo.value("");
  });
}

function draw() {
  background(220);

  text("Lista de Alunos:", 250, 20);

  // Mostrar lista de alunos
  let y = 50;
  for (let i = 0; i < alunos.length; i++) {
    let aluno = alunos[i];
    text(
      `${i+1}. Nome: ${aluno.nome} | Idade: ${aluno.idade} | CPF: ${aluno.cpf} | Sexo: ${aluno.sexo}`,
      250, y
    );
    y += 20;
  }
}

// Função para cadastrar aluno
function cadastrarAluno(nome, idade, cpf, sexo) {
  if (nome && idade && cpf && sexo) {
    let aluno = {
      nome: nome,
      idade: idade,
      cpf: cpf,
      sexo: sexo
    };
    alunos.push(aluno);
  }
}